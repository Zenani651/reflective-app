import 'package:flutter/material.dart';
import 'package:reflective_app/Pages/login_page.dart';
import 'package:reflective_app/Pages/main_page.dart';
import 'package:reflective_app/Pages/not_understood.dart';
import 'package:reflective_app/Pages/understood.dart';

class RouteManager{

  static const String homePage = "/";
  static const String mainPage = "/mainPage";
  static const String notUnderstood = "/notUnderstood";
  static const String understood = "/understood";

  static Route<dynamic>generateRoute (RouteSettings settings)
  {

     switch(settings.name)
     {
      case homePage:
        return MaterialPageRoute(
          builder: (context) =>LoginPage(),
    );
     
     case mainPage:
        return MaterialPageRoute(
          builder: (context) =>MainPage(),
    );

    case notUnderstood:
        return MaterialPageRoute(
          builder: (context) =>NotUnderstand(),
    );

    case understood:
        return MaterialPageRoute(
          builder: (context) =>Understanding(),
    );
      
      default:
      throw FormatException("Route not found check the routes again");
     }

  }
  
}
import 'package:flutter/material.dart';

class RegisterViewModel with ChangeNotifier{
  final loginFormKey = GlobalKey<FormState>();

  void loginUser(String email,String password){
   if(loginFormKey.currentState?.validate() ?? false){
    print("logging user with email: $email, password: $password");
   }
  }
  
  
}
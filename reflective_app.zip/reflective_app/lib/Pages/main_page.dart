import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:reflective_app/Models/user.dart';
import 'package:reflective_app/Routes/routes.dart';
import 'package:reflective_app/widgets/textfields.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  
  // Create a GlobalKey to uniquely identify the Form widget 

final _formKey = GlobalKey<FormState>(); 

// Controllers for handling user input in the TextFormFields 

final TextEditingController understoodController = TextEditingController(); 
final TextEditingController notUnderstoodController = TextEditingController(); 


 
  // Dispose of controllers to avoid memory leaks. 
  @override 
  void dispose() { 
    understoodController.dispose(); 
    notUnderstoodController.dispose(); 
    super.dispose(); 
  }

  @override
  Widget build(BuildContext context) {
   final userEmail = Provider.of<User>(context).username;
    return Scaffold(
        appBar: AppBar(
          title: Text("Reflective App"),
          backgroundColor: Colors.blue,
          ),
    body: Center(
      child: Form(
        key: _formKey,
        child: Column(
        
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Consumer<User>(
            builder: (context, value, child) => Text("Welcome ${value.username}",
            style: TextStyle(fontSize: 24),
            ),
          ),
        const  SizedBox(
            height: 30
          ),
        AppFormField(
           controller: understoodController,
           keyboardType: TextInputType.text,
           hint: '  Please enter what you understand up to so far',
           
        ),
        ElevatedButton(onPressed: (){
                context.read<User>().username = userEmail;         
                
                   if(_formKey.currentState!.validate()){

                Navigator.of(context).pushNamed(RouteManager.understood);
                }
              },
               child: Text("Understood"),
               ),
     const   SizedBox(
          height: 30,
          ),
        
        AppFormField(
           controller: notUnderstoodController,
           keyboardType: TextInputType.text,
           hint: '  Please enter what you dont understand up to so far',
           
        ),
         ElevatedButton(onPressed: (){
                context.read<User>().username = userEmail;         
                
                   if(_formKey.currentState!.validate()){
                Navigator.of(context).pushNamed(RouteManager.notUnderstood);
                }
              },
               child: Text("Not Understood"),
               ),


        ],
      
      ),
        ),
    ),


    );
  }
}
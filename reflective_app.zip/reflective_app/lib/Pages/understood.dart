import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:reflective_app/Models/user.dart';
import 'package:reflective_app/widgets/textfields.dart';

class Understanding extends StatefulWidget {
  const Understanding({super.key});
  

  @override
  State<Understanding> createState() => _UnderstandingState();
}

class _UnderstandingState extends State<Understanding> {
  // Create a GlobalKey to uniquely identify the Form widget 

final _formKey = GlobalKey<FormState>(); 

// Controllers for handling user input in the TextFormFields 
  final TextEditingController strategiesController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<User>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text("Reflective app"),
        backgroundColor: Colors.blue,
        ),
        body: Form(
          key: _formKey,
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
          
              children: [
                Consumer<User>(
                  builder: (context, value, child) {
                    return Text("Welcome ${value.username}",
                  style: TextStyle(fontSize: 25,),
                  );
                  },
                ),
                AppFormField(controller: strategiesController, 
                keyboardType: TextInputType.text,
                hint: "Enter the strategies you used to understand this"
                ),
                SizedBox(
                  height: 20,
                ),
                ElevatedButton(onPressed: (){
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text("Thank you, ${appState.username} your strategies are recieved"),
                      )
                  );
                }, 
                child: Text("Acknowladge"),
                ),
              ],
            ),
            
          ),
        ),
    );
  }
}
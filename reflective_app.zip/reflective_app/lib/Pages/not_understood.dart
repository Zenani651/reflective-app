import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:reflective_app/Models/user.dart';
import 'package:reflective_app/widgets/textfields.dart';

class NotUnderstand extends StatefulWidget {
  const NotUnderstand({super.key});

  @override
  State<NotUnderstand> createState() => _NotUnderstandState();
}

class _NotUnderstandState extends State<NotUnderstand> {

  // Create a GlobalKey to uniquely identify the Form widget 

final _formKey = GlobalKey<FormState>(); 

// Controllers for handling user input in the TextFormFields 
  final TextEditingController improvementsController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<User>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text("Reflective App"),
        backgroundColor: Colors.blue,
      ) ,
      body:Form(
        key: _formKey,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
        
            children: [
              Consumer<User>(
                builder: (context, value, child) {
                  return Text("Welcome ${value.username}",
                style: TextStyle(fontSize: 24),
                );
                },
              ),
              AppFormField(controller: improvementsController, 
                keyboardType: TextInputType.text,
                hint: "Enter the strategies you used to understand this"
                ),
                SizedBox(
                  height: 20,
                ),
                ElevatedButton(onPressed: (){
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text("Thank you, ${appState.username} your strategies are recieved"),
                      )
                  );
                }, 
                child: Text("Acknowladge"),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
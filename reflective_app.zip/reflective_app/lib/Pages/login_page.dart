import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:reflective_app/Models/user.dart';
import 'package:reflective_app/Routes/routes.dart';
import 'package:reflective_app/main.dart';
import 'package:reflective_app/widgets/textfields.dart';


class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  
  // Create a GlobalKey to uniquely identify the Form widget 

final _formKey = GlobalKey<FormState>(); 

// Controllers for handling user input in the TextFormFields 


final TextEditingController userController = TextEditingController(); 
final TextEditingController _passwordController = TextEditingController(); 


  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text("Reflective App"),
        backgroundColor: Colors.blue,
      ),
      body: Form(
        key: _formKey,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
      
          children:<Widget> [
          // Username TextFormField
          SizedBox(
            height: 20,
            ),
          AppFormField(
          controller: userController,
          keyboardType: TextInputType.emailAddress,
          hint: "Please enter your email",
          validator: (value){
            if(value == null || value.isEmpty){
              return "Email is required";
            }else if (!value.contains("@")){
              return "Enter a valid email address";
            }
            return null;
          },
          ),
              const SizedBox(
                height: 20
                ),

              AppFormField(
              
              passwordField: true,
              controller: _passwordController, 
              passwordVisbility: true,
              keyboardType: TextInputType.visiblePassword,
              hint: "Please enter your password",
              validator: (value){
            if(value == null || value.isEmpty){
              return "Password is required";
            }else if (value.length < 8 || !value.contains("@")){
              return "Password must be at least 8 characters long and must include @";
            }
            return null;
          },
              
              ),
        
              SizedBox(
                height: 20,
              ),
              ElevatedButton(onPressed: (){
                context.read<User>().username = userController.text;         
                
                   if(_formKey.currentState!.validate()){
                Navigator.of(context).pushNamed(RouteManager.mainPage);
                }
              },
               child: Text("Login"),
               ),

          ],
        ),
      ),
    );
  }
}


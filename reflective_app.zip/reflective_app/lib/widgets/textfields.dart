import 'package:flutter/material.dart';


class AppFormField extends StatelessWidget {
  const AppFormField({
    super.key,
    required this.controller,this.passwordVisbility = false,
    required this.keyboardType,
    required this.hint,
   this.passwordField = false,
   this.validator,
  

  });

  final TextEditingController controller;
  final bool passwordVisbility;
  final TextInputType keyboardType;
  final String hint;
  final bool passwordField;
  final String? Function(String?)? validator;
  

  @override
  Widget build(BuildContext context) {
    return Padding(
                padding: const EdgeInsets.all(16.0),
                child: TextFormField(
                controller: controller, 
                obscureText: passwordField,
        decoration: InputDecoration( 
          labelText: hint,
          labelStyle: const TextStyle(
            color: Colors.red,
          ),
          enabledBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(10)),
            borderSide: BorderSide(
              color: Color.fromARGB(255, 95, 86, 86),
              width: 1,
            ),
          ),
          focusedBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(10)),
            borderSide: BorderSide(
              color: Color.fromARGB(255, 95, 86, 86),
              width: 2,
            ),
          )
          ),
           validator: validator,
          
                ), 
               );
  }
}